# 🔵 Orbe Breaker

Juego arcade tipo **Pang / Buster Bros**, hecho con **HTML5 + Canvas + JavaScript puro** (sin librerías). Disparas un arpón hacia arriba para reventar orbes que rebotan por el escenario; cada orbe se divide en dos más pequeños al recibir un impacto, hasta desaparecer del todo. Supera los **10 niveles** para ganar.

## 🎮 Controles

| Tecla        | Acción                    |
|--------------|---------------------------|
| `A` / `←`    | Mover a la izquierda      |
| `D` / `→`    | Mover a la derecha        |
| `Espacio`    | Disparar el arpón hacia arriba |

## 🧩 Mecánicas

- Los orbes rebotan en el suelo, techo y paredes siguiendo gravedad realista.
- Al golpear un orbe **grande** o **mediano**, se divide en dos orbes más pequeños que salen despedidos en direcciones opuestas.
- Los orbes **pequeños** desaparecen por completo al recibir un impacto.
- Tocar un orbe con tu nave te cuesta una vida (con un breve periodo de invulnerabilidad tras el golpe). A 0 vidas, `GAME OVER`.
- Al destruir un orbe hay una probabilidad de que caiga una **cápsula de power-up** que debes recoger moviéndote debajo de ella.

## ⚡ Power-ups

| Power-up          | Efecto                                              |
|--------------------|------------------------------------------------------|
| Disparo rápido      | Reduce el tiempo de recarga del arpón durante 10 s   |
| Arpón ancho         | El arpón golpea un área más amplia durante 10 s      |
| Ralentizar orbes    | Reduce la velocidad de todos los orbes durante 8 s   |
| Escudo              | Bloquea el próximo impacto sin perder una vida       |
| Vida extra          | Suma una vida (hasta un máximo de 5)                 |

## 📈 Progresión de dificultad (10 niveles)

Cada nivel añade más orbes iniciales y aumenta su velocidad mediante un multiplicador (`speedMult`), definido en el array `LEVELS` dentro de `game.js`:

- **Niveles 1-3:** 1 o 2 orbes grandes, velocidad base.
- **Niveles 4-6:** 3 o 4 orbes, velocidad creciente, mezcla ocasional de orbes medianos.
- **Niveles 7-10:** 4 a 6 orbes grandes con la velocidad más alta del juego.

Puedes ajustar la curva de dificultad editando directamente el array `LEVELS` o los valores de `BALL_SIZES` en `game.js`.

## 🏁 Fin de la partida

- **Completas los 10 niveles →** `GAME OVER` + `YOU WIN`
- **Te quedas sin vidas antes →** `GAME OVER` (sin "YOU WIN"), mostrando el nivel alcanzado y la puntuación.

## 📁 Estructura de archivos

```
/orbe-breaker
  ├── index.html
  ├── style.css
  ├── game.js
  └── README.md
```

## 🚀 Integración en el arcade BYTEGRID

Para añadirlo al portal, coloca esta carpeta junto a `nave-espacial-vs-oleadas/` en la raíz del repositorio y sustituye una de las cabinas "Próximamente" del `index.html` del portal por:

```html
<article class="cabinet is-live">
  <div class="cabinet-body">
    <h3>Orbe Breaker</h3>
    <p>Revienta orbes tipo Pang a través de 10 niveles de dificultad creciente.</p>
    <div class="cabinet-meta">
      <span class="tag">Arcade</span>
      <span class="tag">10 niveles</span>
    </div>
    <a href="./orbe-breaker/index.html" class="play-btn">Jugar ahora</a>
  </div>
</article>
```
