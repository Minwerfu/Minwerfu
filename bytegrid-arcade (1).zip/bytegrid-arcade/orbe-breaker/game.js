// ============================================================
//  ORBE BREAKER - Juego tipo "Pang" / "Buster Bros"
//  HTML5 Canvas + JavaScript puro (sin dependencias)
// ============================================================

const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const CANVAS_W = canvas.width;
const CANVAS_H = canvas.height;
const GROUND_Y = CANVAS_H - 46;

// ------- Elementos de HUD -------
const hudLevel = document.getElementById('hud-level');
const hudLives = document.getElementById('hud-lives');
const hudScore = document.getElementById('hud-score');
const powerupBar = document.getElementById('powerup-bar');
const overlay = document.getElementById('overlay');
const overlayTitle = document.getElementById('overlay-title');
const overlaySubtitle = document.getElementById('overlay-subtitle');
const overlayExtra = document.getElementById('overlay-extra');
const restartBtn = document.getElementById('restart-btn');
const startHint = document.getElementById('start-hint');

// ============================================================
//  PARÁMETROS DEL JUEGO
// ============================================================
const TOTAL_LEVELS = 10;
const STARTING_LIVES = 3;
const MAX_LIVES = 5;
const GRAVITY = 620;

const PLAYER_SPEED = 340;
const PLAYER_W = 46;
const PLAYER_H = 20;
const BASE_SHOT_COOLDOWN = 0.42;
const INVULN_TIME = 1.4;

// Propiedades por tamaño de bola: 3 = grande, 2 = mediana, 1 = pequeña
const BALL_SIZES = {
  3: { radius: 42, vx: 95, vy: 480, score: 10 },
  2: { radius: 28, vx: 135, vy: 400, score: 20 },
  1: { radius: 16, vx: 175, vy: 320, score: 40 }
};

// Definición de los 10 niveles: de fácil a difícil
const LEVELS = [
  { sizes: [3], speedMult: 1.00 },
  { sizes: [3, 3], speedMult: 1.05 },
  { sizes: [3, 3], speedMult: 1.15 },
  { sizes: [3, 3, 2], speedMult: 1.22 },
  { sizes: [3, 3, 3], speedMult: 1.32 },
  { sizes: [3, 3, 3, 2], speedMult: 1.42 },
  { sizes: [3, 3, 3, 3], speedMult: 1.52 },
  { sizes: [3, 3, 3, 3, 2], speedMult: 1.65 },
  { sizes: [3, 3, 3, 3, 3], speedMult: 1.80 },
  { sizes: [3, 3, 3, 3, 3, 3], speedMult: 1.95 }
];

// Power-ups disponibles
const POWERUP_TYPES = [
  { id: 'rapido', label: 'Disparo rápido', color: '#00f0ff', duration: 10 },
  { id: 'ancho', label: 'Arpón ancho', color: '#ff2e9a', duration: 10 },
  { id: 'lento', label: 'Ralentizar orbes', color: '#7b2ff7', duration: 8 },
  { id: 'escudo', label: 'Escudo', color: '#ffd15c', duration: 0 },
  { id: 'vida', label: 'Vida extra', color: '#6dffb0', duration: 0 }
];
const POWERUP_DROP_CHANCE = 0.22; // probabilidad al destruir un orbe

// ============================================================
//  ESTADO GLOBAL
// ============================================================
let keys = {};
let player, beam, balls, powerups, particles;
let level = 1;
let lives = STARTING_LIVES;
let score = 0;
let activePowerups = {}; // { id: tiempoRestante }
let hasShield = false;
let gameStarted = false;
let state = 'ready'; // ready | playing | transition | gameover | victory
let lastTimestamp = null;
let transitionTimer = 0;

// ============================================================
//  INICIALIZACIÓN
// ============================================================
function resetRun() {
  level = 1;
  lives = STARTING_LIVES;
  score = 0;
  activePowerups = {};
  hasShield = false;
  loadLevel(level);
  updateHud();
}

function loadLevel(n) {
  const cfg = LEVELS[n - 1];
  player = {
    x: CANVAS_W / 2,
    y: GROUND_Y - PLAYER_H / 2,
    w: PLAYER_W,
    h: PLAYER_H,
    lastShot: -999,
    invuln: 0
  };
  beam = null; // { x, y0, y1, timer }
  balls = [];
  powerups = [];
  particles = [];
  activePowerups = {};

  const spacing = CANVAS_W / (cfg.sizes.length + 1);
  cfg.sizes.forEach((size, i) => {
    const def = BALL_SIZES[size];
    const dir = i % 2 === 0 ? 1 : -1;
    balls.push({
      x: spacing * (i + 1),
      y: GROUND_Y - def.radius - 20,
      vx: dir * def.vx * cfg.speedMult,
      vy: -def.vy,
      radius: def.radius,
      size: size,
      speedMult: cfg.speedMult
    });
  });
}

// ============================================================
//  INPUT
// ============================================================
window.addEventListener('keydown', (e) => {
  keys[e.code] = true;
  if (!gameStarted && state === 'ready') {
    if (['KeyA', 'KeyD', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) {
      startGame();
    }
  }
  if (e.code === 'Space') e.preventDefault();
});
window.addEventListener('keyup', (e) => { keys[e.code] = false; });

restartBtn.addEventListener('click', () => {
  resetRun();
  state = 'playing';
  overlay.classList.add('hidden');
  if (!gameStarted) startGame();
});

function startGame() {
  gameStarted = true;
  state = 'playing';
  startHint.style.display = 'none';
  resetRun();
  requestAnimationFrame(loop);
}

// ============================================================
//  DISPARO (ARPÓN)
// ============================================================
function tryShoot(elapsedNow) {
  const cooldown = activePowerups.rapido ? BASE_SHOT_COOLDOWN * 0.5 : BASE_SHOT_COOLDOWN;
  if (elapsedNow - player.lastShot < cooldown) return;
  player.lastShot = elapsedNow;

  const beamHalfWidth = activePowerups.ancho ? 34 : 5;
  let hitBall = null;
  let hitY = 0;

  balls.forEach(b => {
    if (Math.abs(b.x - player.x) <= b.radius + beamHalfWidth) {
      const topOfBall = b.y; // punto donde el arpón "toca" la bola
      if (!hitBall || topOfBall > hitY) {
        hitBall = b;
        hitY = topOfBall;
      }
    }
  });

  beam = { x: player.x, y0: player.y - player.h / 2, y1: hitBall ? hitY : 0, timer: 0.12, wide: !!activePowerups.ancho };

  if (hitBall) {
    popBall(hitBall);
  }
}

function popBall(ball) {
  const idx = balls.indexOf(ball);
  if (idx === -1) return;
  balls.splice(idx, 1);
  score += BALL_SIZES[ball.size].score;
  spawnParticles(ball.x, ball.y, ball.size === 3 ? '#ff5c5c' : ball.size === 2 ? '#ff9c4a' : '#ffe27a');

  if (ball.size > 1) {
    const newSize = ball.size - 1;
    const def = BALL_SIZES[newSize];
    [1, -1].forEach(dir => {
      balls.push({
        x: ball.x,
        y: ball.y,
        vx: dir * def.vx * ball.speedMult,
        vy: -def.vy,
        radius: def.radius,
        size: newSize,
        speedMult: ball.speedMult
      });
    });
  }

  if (Math.random() < POWERUP_DROP_CHANCE) {
    const type = POWERUP_TYPES[Math.floor(Math.random() * POWERUP_TYPES.length)];
    powerups.push({ x: ball.x, y: ball.y, vy: 0, type });
  }

  updateHud();
}

// ============================================================
//  ACTUALIZACIÓN
// ============================================================
function update(dt, elapsedNow) {
  // --- Movimiento del jugador ---
  let dx = 0;
  if (keys['KeyA'] || keys['ArrowLeft']) dx -= 1;
  if (keys['KeyD'] || keys['ArrowRight']) dx += 1;
  player.x += dx * PLAYER_SPEED * dt;
  player.x = Math.max(player.w / 2, Math.min(CANVAS_W - player.w / 2, player.x));

  if (player.invuln > 0) player.invuln -= dt;

  // --- Disparo ---
  if (keys['Space']) tryShoot(elapsedNow);

  // --- Temporizador del rayo visual ---
  if (beam) {
    beam.timer -= dt;
    if (beam.timer <= 0) beam = null;
  }

  // --- Power-ups activos (temporizadores) ---
  Object.keys(activePowerups).forEach(id => {
    activePowerups[id] -= dt;
    if (activePowerups[id] <= 0) delete activePowerups[id];
  });

  const slowFactor = activePowerups.lento ? 0.55 : 1;

  // --- Física de las bolas ---
  balls.forEach(b => {
    b.vy += GRAVITY * dt;
    b.x += b.vx * slowFactor * dt;
    b.y += b.vy * slowFactor * dt;

    if (b.x - b.radius < 0) { b.x = b.radius; b.vx *= -1; }
    if (b.x + b.radius > CANVAS_W) { b.x = CANVAS_W - b.radius; b.vx *= -1; }
    if (b.y - b.radius < 0) { b.y = b.radius; b.vy = Math.abs(b.vy); }
    if (b.y + b.radius > GROUND_Y) { b.y = GROUND_Y - b.radius; b.vy = -Math.abs(b.vy); }
  });

  // --- Colisión bola vs jugador ---
  if (player.invuln <= 0) {
    for (const b of balls) {
      const dist = Math.hypot(b.x - player.x, b.y - player.y);
      if (dist < b.radius + Math.max(player.w, player.h) / 2.6) {
        handlePlayerHit();
        break;
      }
    }
  }

  // --- Power-ups cayendo ---
  powerups.forEach(p => {
    p.vy += GRAVITY * 0.5 * dt;
    p.y += p.vy * dt;
  });
  powerups = powerups.filter(p => {
    if (p.y > CANVAS_H + 30) return false;
    const dist = Math.hypot(p.x - player.x, p.y - player.y);
    if (dist < 24) {
      applyPowerup(p.type);
      return false;
    }
    return true;
  });

  // --- Partículas ---
  particles.forEach(pt => { pt.x += pt.vx * dt; pt.y += pt.vy * dt; pt.life -= dt; });
  particles = particles.filter(pt => pt.life > 0);

  // --- ¿Nivel superado? ---
  if (balls.length === 0) {
    completeLevel();
  }

  updateHud();
}

function handlePlayerHit() {
  if (hasShield) {
    hasShield = false;
    delete activePowerups.escudo;
    player.invuln = INVULN_TIME;
    spawnParticles(player.x, player.y, '#ffd15c');
    updateHud();
    return;
  }
  lives -= 1;
  player.invuln = INVULN_TIME;
  spawnParticles(player.x, player.y, '#ff2e9a');
  updateHud();
  if (lives <= 0) {
    endGame(false);
  }
}

function applyPowerup(type) {
  if (type.id === 'vida') {
    lives = Math.min(lives + 1, MAX_LIVES);
  } else if (type.id === 'escudo') {
    hasShield = true;
    activePowerups.escudo = 1; // marcador visual permanente hasta usarse
  } else {
    activePowerups[type.id] = type.duration;
  }
  updateHud();
}

function completeLevel() {
  if (state !== 'playing') return;
  state = 'transition';
  transitionTimer = 1.8;
  if (level >= TOTAL_LEVELS) {
    endGame(true);
  } else {
    showOverlay(`NIVEL ${level} SUPERADO`, '', '', 'level-up');
  }
}

function endGame(didWin) {
  state = didWin ? 'victory' : 'gameover';
  if (didWin) {
    showOverlay('GAME OVER', 'YOU WIN', `Puntuación final: ${score}`, 'win');
  } else {
    showOverlay('GAME OVER', '', `Llegaste al nivel ${level} · Puntuación: ${score}`, '');
  }
}

function showOverlay(title, subtitle, extra, cls) {
  overlayTitle.textContent = title;
  overlayTitle.className = cls || '';
  overlaySubtitle.textContent = subtitle;
  overlayExtra.textContent = extra;
  overlay.classList.remove('hidden');
}

// ============================================================
//  PARTÍCULAS (efecto de explosión al reventar un orbe)
// ============================================================
function spawnParticles(x, y, color) {
  for (let i = 0; i < 12; i++) {
    const ang = Math.random() * Math.PI * 2;
    const spd = 60 + Math.random() * 140;
    particles.push({
      x, y,
      vx: Math.cos(ang) * spd,
      vy: Math.sin(ang) * spd,
      life: 0.35 + Math.random() * 0.25,
      color
    });
  }
}

// ============================================================
//  HUD
// ============================================================
function updateHud() {
  hudLevel.textContent = level;
  hudLives.textContent = '❤️'.repeat(Math.max(lives, 0)) || '💀';
  hudScore.textContent = score;

  powerupBar.innerHTML = '';
  if (hasShield) {
    powerupBar.innerHTML += `<span class="powerup-chip">🛡️ Escudo</span>`;
  }
  Object.keys(activePowerups).forEach(id => {
    if (id === 'escudo') return;
    const def = POWERUP_TYPES.find(p => p.id === id);
    if (def) {
      powerupBar.innerHTML += `<span class="powerup-chip">${def.label} (${Math.ceil(activePowerups[id])}s)</span>`;
    }
  });
}

// ============================================================
//  RENDER
// ============================================================
function draw() {
  ctx.clearRect(0, 0, CANVAS_W, CANVAS_H);
  drawBackground();

  // Suelo
  ctx.fillStyle = '#0d1326';
  ctx.fillRect(0, GROUND_Y, CANVAS_W, CANVAS_H - GROUND_Y);
  ctx.strokeStyle = 'rgba(0, 240, 255, 0.4)';
  ctx.beginPath();
  ctx.moveTo(0, GROUND_Y);
  ctx.lineTo(CANVAS_W, GROUND_Y);
  ctx.stroke();

  // Jugador (parpadea si está invulnerable)
  if (Math.floor(player.invuln * 12) % 2 === 0 || player.invuln <= 0) {
    ctx.fillStyle = hasShield ? '#ffd15c' : '#00f0ff';
    ctx.shadowColor = ctx.fillStyle;
    ctx.shadowBlur = 10;
    ctx.fillRect(player.x - player.w / 2, player.y - player.h / 2, player.w, player.h);
    ctx.shadowBlur = 0;
  }

  // Rayo del arpón
  if (beam) {
    ctx.strokeStyle = beam.wide ? 'rgba(255, 46, 154, 0.85)' : 'rgba(0, 240, 255, 0.9)';
    ctx.lineWidth = beam.wide ? 8 : 3;
    ctx.shadowColor = ctx.strokeStyle;
    ctx.shadowBlur = 10;
    ctx.beginPath();
    ctx.moveTo(beam.x, beam.y0);
    ctx.lineTo(beam.x, beam.y1);
    ctx.stroke();
    ctx.shadowBlur = 0;
  }

  // Bolas
  balls.forEach(b => {
    const color = b.size === 3 ? '#ff5c5c' : b.size === 2 ? '#ff9c4a' : '#ffe27a';
    ctx.fillStyle = color;
    ctx.shadowColor = color;
    ctx.shadowBlur = 12;
    ctx.beginPath();
    ctx.arc(b.x, b.y, b.radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.strokeStyle = 'rgba(255,255,255,0.25)';
    ctx.beginPath();
    ctx.arc(b.x, b.y, b.radius * 0.6, 0, Math.PI * 2);
    ctx.stroke();
  });

  // Power-ups cayendo
  powerups.forEach(p => {
    ctx.fillStyle = p.type.color;
    ctx.shadowColor = p.type.color;
    ctx.shadowBlur = 10;
    ctx.beginPath();
    ctx.arc(p.x, p.y, 12, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.fillStyle = '#05070d';
    ctx.font = 'bold 12px Orbitron, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('+', p.x, p.y + 1);
  });

  // Partículas
  particles.forEach(pt => {
    ctx.globalAlpha = Math.max(pt.life, 0);
    ctx.fillStyle = pt.color;
    ctx.fillRect(pt.x - 2, pt.y - 2, 4, 4);
    ctx.globalAlpha = 1;
  });
}

let stars = null;
function drawBackground() {
  if (!stars) {
    stars = [];
    for (let i = 0; i < 70; i++) {
      stars.push({ x: Math.random() * CANVAS_W, y: Math.random() * CANVAS_H, r: Math.random() * 1.4 + 0.3 });
    }
  }
  ctx.fillStyle = '#ffffff';
  stars.forEach(s => {
    ctx.globalAlpha = 0.4;
    ctx.beginPath();
    ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
    ctx.fill();
  });
  ctx.globalAlpha = 1;
}

// ============================================================
//  BUCLE PRINCIPAL
// ============================================================
let elapsedTotal = 0;

function loop(timestamp) {
  if (lastTimestamp === null) lastTimestamp = timestamp;
  const dt = Math.min((timestamp - lastTimestamp) / 1000, 0.05);
  lastTimestamp = timestamp;
  elapsedTotal += dt;

  if (state === 'playing') {
    update(dt, elapsedTotal);
  } else if (state === 'transition') {
    transitionTimer -= dt;
    if (transitionTimer <= 0) {
      overlay.classList.add('hidden');
      level += 1;
      loadLevel(level);
      state = 'playing';
    }
  }

  draw();

  if (state !== 'gameover' && state !== 'victory') {
    requestAnimationFrame(loop);
  }
}

// ------- Arranque inicial (pantalla de espera) -------
resetRun();
draw();
